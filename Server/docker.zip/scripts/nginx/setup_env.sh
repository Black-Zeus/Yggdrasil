#!/bin/sh
echo "Configuring environment for: $VITE_FRONTEND_ENV"
echo "VITE_FRONTEND_ENV=$VITE_FRONTEND_ENV" >> .env
