
-- ====================================
-- CREACIÓN DE Usario DB
-- ====================================
--Nokto — de noche en esperanto, suena a sistema que funciona en segundo plano o analiza sin que lo veas.

-- Asignar privilegios completos al usuario 'nokto' en la base de datos 'Nokto'
GRANT ALL PRIVILEGES ON Nokto.* TO 'nokto'@'%';

-- Asignar privilegios completos al usuario 'root' en todas las bases de datos, pero solo desde 'localhost'
GRANT ALL PRIVILEGES ON *.* TO 'root'@'localhost' WITH GRANT OPTION;

-- Aplicar cambios en privilegios
FLUSH PRIVILEGES;
